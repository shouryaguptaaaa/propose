# 15.09 — A Special Story for Siya

A pink-and-white, mobile-friendly proposal website starter with 100 compliments, seven-photo gallery, optional music, Firebase message submission and a Firebase-authenticated admin dashboard.

## Files to add
- `assets/images/a.jpg` through `g.jpg` — your seven image files.
- `assets/music/music.mp3` — your music file.

The ZIP includes empty placeholder files with these names. Replace them with the real files.

## Configure Firebase
1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web App and copy its Firebase config into `firebase-config.js`.
3. Enable **Authentication → Email/Password**.
4. Create your admin user in Firebase Authentication.
5. Create a **Cloud Firestore** database.
6. Copy your admin user's UID and replace `REPLACE_WITH_ADMIN_UID` in `firebase/firestore.rules`.
7. Publish the rules in Firestore → Rules.

Do not publish the rules with the placeholder UID still present. Until you replace it, nobody will be able to read the admin dashboard data.

## Run locally
Because this project uses JavaScript modules, serve it with a local static server (for example VS Code Live Server). Opening `index.html` directly as a `file://` URL may not work.

## Deploy
You can deploy the site on GitHub Pages. Keep the `admin/` folder and all assets in the repository. The admin page URL will be `/admin/`.

## Important notes
- The No button shows up to 100 playful messages and remains available. A separate “I mean no” action records a genuine No response.
- Yes and No are both respected choices.
- Music starts only after the visitor presses Play, because browsers generally block autoplay with sound.
- Firebase web config is not a password, but Firestore Security Rules are essential. Never put service-account private keys in this website.
- This starter does not include real photos, music, or Firebase credentials. Add your own files and config before deployment.

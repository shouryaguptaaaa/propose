import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "../firebase-config.js";

const reasons = [
"Your smile can brighten an ordinary day.","You have your own way of making moments memorable.","Your personality is worth appreciating.","You deserve kindness and respect.","You bring your own perspective to things.",
"Your little expressions are lovely.","You have a style that is uniquely yours.","You can make simple moments feel special.","You have qualities that words cannot fully capture.","You are more than anyone's first impression.",
"Your thoughts matter.","Your laughter is a lovely sound.","You have your own little spark.","You deserve to be celebrated for being yourself.","You make this world a little more interesting.",
"Your confidence can be inspiring.","You have a memorable presence.","Your kindness matters.","You have a way of standing out without trying.","You are one of a kind.",
"Your small achievements deserve applause.","You have a lovely way of expressing yourself.","Your dreams are worth chasing.","You deserve people who listen to you.","Your individuality is beautiful.",
"You can turn a regular conversation into a good memory.","Your energy is uniquely yours.","You have so many sides worth discovering.","You deserve to feel appreciated.","You make being yourself look effortless.",
"Your opinions deserve to be heard.","You have a lovely sense of individuality.","Your presence can make a difference.","You deserve genuine compliments.","You have your own kind of charm.",
"Your curiosity is a good quality.","You can inspire a smile without knowing it.","Your honesty is valuable.","You deserve happiness in little things.","You are worth getting to know.",
"Your way of looking at the world is interesting.","You have a memorable way of speaking.","You deserve patience and understanding.","Your efforts matter, even when unseen.","You have a bright future ahead.",
"Your uniqueness is not something to change.","You make ordinary details feel meaningful.","You deserve sincere friendships.","Your smile has its own story.","You are allowed to take up space and be yourself.",
"Your creativity deserves room to grow.","You have a lovely presence in a room.","You deserve encouragement.","Your little habits make you you.","You have a lot to be proud of.",
"Your happiness matters.","You can make a day feel lighter.","You deserve to be understood.","Your individuality makes you special.","You have a thoughtful side worth knowing.",
"You are not defined by anyone else's opinion.","Your goals deserve attention.","You have your own rhythm.","You deserve good things without having to earn kindness.","Your perspective can teach others something.",
"You have a lovely way of being yourself.","You make memories in your own way.","You deserve to be treated with care.","Your personality is not replaceable.","You have so much potential.",
"You can make a simple hello feel nice.","Your courage matters.","You deserve people who respect your boundaries.","You have a story only you can tell.","Your presence is appreciated.",
"You have a special mix of qualities.","You deserve to feel proud of yourself.","Your dreams are important.","You have a beautiful individuality.","You make this little page worth creating.",
"Your voice deserves to be heard.","You deserve calm and happy days.","Your efforts never need to be compared.","You have your own kind of magic.","You are worth celebrating on ordinary days.",
"You can be both strong and gentle.","You deserve to be accepted as you are.","Your little wins count.","You have a lovely way of making things yours.","You deserve respect in every answer you give.",
"You are a person, not a perfect idea.","You deserve space to choose freely.","Your happiness should always matter.","You are special simply because you are you.","And the hundredth reason: there is only one Siya."
];
const grid = document.querySelector("#reasonsGrid");
reasons.forEach((reason,i)=>{const card=document.createElement("article");card.className="reason-card";card.innerHTML=`<b>REASON ${String(i+1).padStart(2,"0")}</b><p></p>`;card.querySelector("p").textContent=reason;grid.append(card);});

const noLines = [
"That is a very clear no—and I respect it. 🌷","A tiny playful reminder: your choice comes first. ♡","No worries. Your honesty is appreciated.","You don't owe anyone a yes.","A smile is lovely, but your comfort matters more.","No is a complete answer. Thank you for being honest.","This button has more lines, but your answer stays yours.","You are allowed to choose what feels right.","No pressure, Siya. Take care of yourself.","Even this little website knows boundaries matter."
];
for(let i=11;i<=100;i++) noLines.push([
"Plot twist: respect is still the main character. ♡",
"Your choice matters more than any cute line.",
"One more message, zero pressure.",
"An honest answer is always appreciated.",
"Your comfort comes first—always.",
"Still cheering for your happiness, whatever you choose.",
"Your answer doesn't need an explanation.",
"Thanks for taking a moment to read this.",
"Kindness looks good in every answer.",
"No pressure, just a little pink webpage."
][(i-11)%10]);

let noCount=0;
const noLine=document.querySelector("#noLine");
document.querySelector("#noButton").addEventListener("click",()=>{
  const line=noLines[noCount%100];
  noCount++;
  noLine.textContent=`${line}  (${Math.min(noCount,100)}/100 playful messages)`;
  if(noCount>=100) noLine.textContent="You've seen all 100 messages. Your answer is still completely yours. ♡";
});
document.querySelector("#clearNoButton").addEventListener("click",async()=>{
  noLine.textContent="Your answer has been recorded. Thank you for being honest.";
  document.querySelector("#proposal").classList.add("hidden");
  document.querySelector("#afterNo").classList.remove("hidden");
  await saveResponse("no");
});

const yesButton=document.querySelector("#yesButton");
yesButton.addEventListener("click",async()=>{
  document.querySelector("#proposal").classList.add("hidden");
  document.querySelector("#afterYes").classList.remove("hidden");
  await saveResponse("yes");
  document.querySelector("#afterYes").scrollIntoView({behavior:"smooth"});
});
let db=null;
try{
  if(firebaseConfig && firebaseConfig.apiKey && firebaseConfig.apiKey!=="YOUR_API_KEY"){
    const app=initializeApp(firebaseConfig); db=getFirestore(app);
  }
}catch(err){console.warn("Firebase is not configured yet.",err);}
async function saveResponse(choice){
  if(!db){sessionStorage.setItem("siya-choice",choice);return;}
  try{await addDoc(collection(db,"responses"),{choice,createdAt:serverTimestamp(),noClicks:noCount});}
  catch(err){console.error(err);noLine.textContent="Your choice is shown here, but online saving is not configured yet.";}
}
document.querySelector("#sendMessage").addEventListener("click",async()=>{
  const box=document.querySelector("#herMessage"),status=document.querySelector("#messageStatus");
  const message=box.value.trim();
  if(!message){status.textContent="Please write a message first.";return;}
  if(!db){status.textContent="Firebase setup is needed before messages can be sent.";return;}
  try{await addDoc(collection(db,"messages"),{message,createdAt:serverTimestamp()});box.value="";status.textContent="Your message has been sent. Thank you! ♡";}
  catch(err){console.error(err);status.textContent="Could not send right now. Please try again later.";}
});
const music=document.querySelector("#bgMusic"),musicToggle=document.querySelector("#musicToggle");
musicToggle.addEventListener("click",async()=>{
  try{if(music.paused){await music.play();musicToggle.innerHTML="♫ <span>Pause music</span>";}else{music.pause();musicToggle.innerHTML="♫ <span>Play music</span>";}}
  catch(e){musicToggle.innerHTML="♫ <span>Music unavailable</span>";}
});

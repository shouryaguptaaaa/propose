import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, query, orderBy, onSnapshot } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "../firebase-config.js";
const status=document.querySelector("#status"),loginArea=document.querySelector("#loginArea"),dashboard=document.querySelector("#dashboard");
let auth,db,unsubResponses,unsubMessages;
try{
 if(!firebaseConfig.apiKey || firebaseConfig.apiKey==="YOUR_API_KEY") throw new Error("Add your Firebase web config in firebase-config.js first.");
 const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
}catch(e){status.textContent=e.message;}
document.querySelector("#login").addEventListener("click",async()=>{
 try{await signInWithEmailAndPassword(auth,document.querySelector("#email").value.trim(),document.querySelector("#password").value);}
 catch(e){status.textContent="Sign-in failed: "+e.message;}
});
document.querySelector("#logout").addEventListener("click",()=>signOut(auth));
if(auth) onAuthStateChanged(auth,user=>{
 if(unsubResponses)unsubResponses();if(unsubMessages)unsubMessages();
 loginArea.hidden=!!user;dashboard.hidden=!user;
 if(!user)return;
 document.querySelector("#adminEmail").textContent=user.email||"Admin";
 // Firestore rules must restrict reads to your admin UID.
 unsubResponses=onSnapshot(query(collection(db,"responses"),orderBy("createdAt","desc")),snap=>{
  const root=document.querySelector("#responses");root.replaceChildren();
  if(snap.empty){root.textContent="No responses yet.";return;}
  snap.forEach(doc=>{const d=doc.data(),el=document.createElement("article");el.className="item";el.textContent=`Answer: ${String(d.choice||"").toUpperCase()} · No button clicks: ${d.noClicks??0}`;const small=document.createElement("small");small.textContent=d.createdAt?.toDate?.().toLocaleString()||"Time not available";el.append(small);root.append(el);});
 },e=>status.textContent="Could not load responses: "+e.message);
 unsubMessages=onSnapshot(query(collection(db,"messages"),orderBy("createdAt","desc")),snap=>{
  const root=document.querySelector("#messages");root.replaceChildren();
  if(snap.empty){root.textContent="No messages yet.";return;}
  snap.forEach(doc=>{const d=doc.data(),el=document.createElement("article");el.className="item";el.textContent=String(d.message||"");const small=document.createElement("small");small.textContent=d.createdAt?.toDate?.().toLocaleString()||"Time not available";el.append(small);root.append(el);});
 },e=>status.textContent="Could not load messages: "+e.message);
});
